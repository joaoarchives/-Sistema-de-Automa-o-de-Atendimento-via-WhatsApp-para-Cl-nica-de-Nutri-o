from services.bot import processar_mensagem

telefone = "5561999999999"

print("Bot iniciado. Digite 'sair' para encerrar.\n")

while True:
    msg = input("Você: ")
    if msg.lower() == "sair":
        break

    resposta = processar_mensagem(telefone, msg)

    print(f"Bot: {resposta.texto}")

    # Se for lista interativa, exibe os horários como texto numerado
    if resposta.tipo == "lista":
        i = 1
        for secao in resposta.lista_secoes:
            print(f"\n  [{secao['title']}]")
            for row in secao["rows"]:
                print(f"  {i} - {row['title']}")
                i += 1
        print(f"\n  (No WhatsApp aparecerá como lista clicável)")

    print()