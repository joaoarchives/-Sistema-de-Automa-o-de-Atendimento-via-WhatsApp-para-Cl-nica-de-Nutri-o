from services.bot import processar_mensagem

telefone = "5561999999999"

print("Bot iniciado. Digite 'sair' para encerrar.\n")

while True:
    msg = input("Você: ")
    if msg.lower() == "sair":
        break
    resposta = processar_mensagem(telefone, msg)
    print(f"Bot: {resposta}\n")